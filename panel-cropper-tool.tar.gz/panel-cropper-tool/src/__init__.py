"""Panel cropper tool"""
